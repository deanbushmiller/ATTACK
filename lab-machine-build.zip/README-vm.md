# Caldera server VMware VM

## Files here
- caldera-server.vmx  the VM configuration
- caldera-server.vmdk the empty 30 GB virtual disk
- seed.iso            the autoinstall answer disk

## One file you add
Download the Ubuntu Server 22.04 ISO and place it in THIS folder.
Rename it to exactly:

    ubuntu-22.04-live-server-amd64.iso

Link: https://releases.ubuntu.com/22.04/

## Open it
1. In VMware, choose Open a Virtual Machine.
2. Pick caldera-server.vmx.
3. Power on.
4. At the GRUB menu press e, add a space and the word autoinstall to the
   line that starts with linux, then press Ctrl and X.
5. Wait. The VM installs Ubuntu, then installs Caldera, then serves on port 8888.

## Notes
- Network is NAT. Good for install and for the victim to reach later.
- Secure Boot is off on purpose.
- After install you can disconnect both CD drives.
- Default logins: Ubuntu student / student, Caldera web red / admin.
